awesome-wm-config
=================

rc.lua and other stuff for Awesome WM

rc.lua is based on the *Holo* theme from
[copycat-killer](https://github.com/copycat-killer/awesome-copycats)

Needs rxvt-unicode as well as other packages (see rc.lua)
